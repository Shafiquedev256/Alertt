# Forex Alerts (Flutter + Binance)

Real-time price alerts for **Gold, BTC, US Oil (WTI)** and **forex majors**, powered by
Binance WebSocket streams. A foreground service keeps the connection alive and rings an
**alarm-stream notification** (loops until dismissed) even when the phone is locked.

## Setup

```bash
flutter create --org com.example --project-name forex_alert forex_alert_app
cd forex_alert_app
# copy this package's files over the generated project:
cp -r ../forex_alert/lib ../forex_alert/pubspec.yaml .
cp ../forex_alert/android_overlay/app/src/main/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
flutter pub get
```

### Required Gradle change (flutter_local_notifications needs desugaring)

`android/app/build.gradle(.kts)`:

Groovy:
```gradle
android {
    compileOptions { coreLibraryDesugaringEnabled true }
}
dependencies {
    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'
}
```
Kotlin DSL:
```kotlin
android {
    compileOptions { isCoreLibraryDesugaringEnabled = true }
}
dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}
```

Run on a **real Android device**: `flutter run --release` (emulators don't behave like phones
for background/lock-screen tests).

## First run checklist (Setup tab)
1. Allow notifications.
2. Disable battery optimisation for the app.
3. On Xiaomi/Oppo/Vivo/Samsung/Huawei: enable Autostart and lock the app in Recents.
4. Lock the phone, tap **Test alarm**: you should hear the alarm ringtone.

## How it works
- `monitor.dart` (background isolate): checks which symbols really exist on Binance, opens
  one combined WebSocket per market (spot + futures), auto-reconnects with backoff, a
  watchdog restarts dead sockets, and every tick is compared against your alerts.
- `notifier.dart`: alarm channel (ALARM audio usage, max importance, full-screen intent,
  insistent flag) so it rings through a locked screen.
- Alerts auto-detect direction: set a target above the current price -> fires on >=,
  below -> fires on <=. An alert fires once; flip its switch to re-arm.

## Markets and Binance's coverage
Binance is a crypto exchange. It does not list a full interbank forex market:
- Gold: `XAUUSDT` perpetual (futures) and `PAXGUSDT` (spot token).
- US Oil: `CLUSDT` (WTI perp), `BZUSDT` (Brent perp).
- Forex: spot `EURUSDT`, `GBPUSDT`, `AUDUSDT` vs USDT, plus Binance's FX perps as they roll out.
  Candidates for NZD, JPY, CAD, CHF are in `lib/config.dart`; the app hides any that Binance
  doesn't list. Use the **+** button to add any symbol.
- These are Binance-quoted prices (USDT-based / perpetual contracts), not interbank spot, so
  they can differ slightly from your forex broker. Commodity perps follow Binance's trading
  schedule and can be flat on weekends.

## Notes
- Binance.US or restricted regions: edit endpoints in `lib/config.dart`.
- Android 15 limits `dataSync` foreground services to ~6h, so this uses `specialUse`
  (declared in the manifest). Publishing on Google Play requires a justification for it.
- iOS cannot keep a socket open in the background; reliable locked-phone alerts on iOS need
  a small server sending push notifications. This package targets Android.
- Informational tool only, not financial advice.
