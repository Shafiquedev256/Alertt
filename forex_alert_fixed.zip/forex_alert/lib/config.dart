import 'models.dart';

// Binance.US users: swap these for api.binance.us / stream.binance.us:9443.
const kSpotRest = 'https://api.binance.com';
const kSpotWs = 'wss://stream.binance.com:9443';
const kFuturesRest = 'https://fapi.binance.com';
const kFuturesWs = 'wss://fstream.binance.com';

/// Candidate markets. At startup the app checks each symbol against Binance
/// and silently hides the ones Binance does not list, so it is safe to keep
/// extra candidates here. Add your own in the app with the "+" button.
const kCatalog = <Instrument>[
  // Crypto
  Instrument('BTCUSDT', 'Bitcoin (BTC/USDT)', 'Crypto', Market.spot),

  // Gold
  Instrument('XAUUSDT', 'Gold XAU/USD (perp)', 'Gold', Market.futures),
  Instrument('PAXGUSDT', 'Gold PAXG token (spot)', 'Gold', Market.spot),

  // US oil (WTI) + Brent
  Instrument('CLUSDT', 'US Oil WTI (perp)', 'Oil', Market.futures),
  Instrument('BZUSDT', 'Brent Oil (perp)', 'Oil', Market.futures),

  // Forex majors - spot, USDT-quoted
  Instrument('EURUSDT', 'EUR/USD (spot)', 'Forex majors', Market.spot),
  Instrument('GBPUSDT', 'GBP/USD (spot)', 'Forex majors', Market.spot),
  Instrument('AUDUSDT', 'AUD/USD (spot)', 'Forex majors', Market.spot),
  Instrument('NZDUSDT', 'NZD/USD (spot)', 'Forex majors', Market.spot),
  Instrument('USDTJPY', 'USD/JPY (spot)', 'Forex majors', Market.spot),
  Instrument('USDTCAD', 'USD/CAD (spot)', 'Forex majors', Market.spot),
  Instrument('USDTCHF', 'USD/CHF (spot)', 'Forex majors', Market.spot),

  // Forex majors - FX perpetuals (Binance TradFi FX perps, rolling out)
  Instrument('EURUSDUSDT', 'EUR/USD (perp)', 'Forex majors', Market.futures),
  Instrument('GBPUSDUSDT', 'GBP/USD (perp)', 'Forex majors', Market.futures),
  Instrument('AUDUSDUSDT', 'AUD/USD (perp)', 'Forex majors', Market.futures),
  Instrument('NZDUSDUSDT', 'NZD/USD (perp)', 'Forex majors', Market.futures),
  Instrument('USDJPYUSDT', 'USD/JPY (perp)', 'Forex majors', Market.futures),
  Instrument('USDCADUSDT', 'USD/CAD (perp)', 'Forex majors', Market.futures),
  Instrument('USDCHFUSDT', 'USD/CHF (perp)', 'Forex majors', Market.futures),
];
