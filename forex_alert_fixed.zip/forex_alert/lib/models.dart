enum Market { spot, futures }

class Instrument {
  const Instrument(this.symbol, this.label, this.group, this.market);
  final String symbol;
  final String label;
  final String group;
  final Market market;

  String get key => '${market.name}:$symbol';

  Map<String, dynamic> toJson() =>
      {'s': symbol, 'l': label, 'g': group, 'm': market.name};

  factory Instrument.fromJson(Map<String, dynamic> j) => Instrument(
        j['s'] as String,
        j['l'] as String,
        j['g'] as String,
        Market.values.byName(j['m'] as String),
      );
}

class AlertRule {
  AlertRule({
    required this.id,
    required this.key,
    required this.label,
    required this.above,
    required this.target,
    this.active = true,
    this.firedAt,
    this.firedPrice,
    this.note = '',
    this.tonePath,
    this.toneName,
  });

  final String id;
  final String key; // Instrument.key
  final String label;
  final bool above; // true: fire when price >= target, false: price <= target
  final double target;
  bool active;
  int? firedAt;
  double? firedPrice;
  final String note; // why the user set this alert
  final String? tonePath; // custom ringtone file; null = default alarm
  final String? toneName;

  Map<String, dynamic> toJson() => {
        'id': id,
        'k': key,
        'l': label,
        'a': above,
        't': target,
        'on': active,
        'fa': firedAt,
        'fp': firedPrice,
        'n': note,
        'tp': tonePath,
        'tn': toneName,
      };

  factory AlertRule.fromJson(Map<String, dynamic> j) => AlertRule(
        id: j['id'] as String,
        key: j['k'] as String,
        label: j['l'] as String,
        above: j['a'] as bool,
        target: (j['t'] as num).toDouble(),
        active: j['on'] as bool? ?? true,
        firedAt: j['fa'] as int?,
        firedPrice: (j['fp'] as num?)?.toDouble(),
        note: j['n'] as String? ?? '',
        tonePath: j['tp'] as String?,
        toneName: j['tn'] as String?,
      );
}

String fmtPrice(double p) {
  if (p >= 1000) return p.toStringAsFixed(2);
  if (p >= 100) return p.toStringAsFixed(3);
  if (p >= 10) return p.toStringAsFixed(4);
  if (p >= 1) return p.toStringAsFixed(5);
  return p.toStringAsFixed(6);
}
