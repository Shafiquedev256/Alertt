import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';

/// Loops an alarm sound on the ALARM audio stream until stop() is called.
/// Lives in the background-service isolate, so it keeps ringing with the
/// screen off and the app closed.
class Ringer {
  AudioPlayer? _player;

  bool get ringing => _player != null;

  Future<void> start(String? customPath) async {
    if (_player != null) return; // already ringing; one Stop silences all
    final p = AudioPlayer();
    _player = p;
    try {
      await p.setAudioContext(AudioContext(
        android: const AudioContextAndroid(
          usageType: AndroidUsageType.alarm,
          contentType: AndroidContentType.sonification,
          audioFocus: AndroidAudioFocus.gain,
          stayAwake: true,
        ),
      ));
      await p.setReleaseMode(ReleaseMode.loop);
      if (customPath != null && File(customPath).existsSync()) {
        try {
          await p.play(DeviceFileSource(customPath));
          return;
        } catch (_) {} // unplayable file: fall back to the default tone
      }
      await p.play(DeviceFileSource(await _defaultTone()));
    } catch (_) {}
  }

  Future<void> stop() async {
    final p = _player;
    _player = null;
    if (p == null) return;
    try {
      await p.stop();
      await p.dispose();
    } catch (_) {}
  }

  /// Built-in alarm tone, generated once as a small WAV (4 beeps + pause).
  static Future<String> _defaultTone() async {
    final dir = await getApplicationSupportDirectory();
    final f = File('${dir.path}/default_alarm.wav');
    if (f.existsSync()) return f.path;

    const rate = 22050;
    const beep = (rate * 0.18) ~/ 1;
    const gap = (rate * 0.12) ~/ 1;
    const tail = (rate * 0.6) ~/ 1;
    const n = 4 * (beep + gap) + tail;
    final data = ByteData(44 + n * 2);
    void tag(int o, String s) {
      for (var i = 0; i < 4; i++) {
        data.setUint8(o + i, s.codeUnitAt(i));
      }
    }

    tag(0, 'RIFF');
    data.setUint32(4, 36 + n * 2, Endian.little);
    tag(8, 'WAVE');
    tag(12, 'fmt ');
    data.setUint32(16, 16, Endian.little);
    data.setUint16(20, 1, Endian.little); // PCM
    data.setUint16(22, 1, Endian.little); // mono
    data.setUint32(24, rate, Endian.little);
    data.setUint32(28, rate * 2, Endian.little);
    data.setUint16(32, 2, Endian.little);
    data.setUint16(34, 16, Endian.little);
    tag(36, 'data');
    data.setUint32(40, n * 2, Endian.little);
    for (var b = 0; b < 4; b++) {
      for (var i = 0; i < beep; i++) {
        final env = min(1.0, min(i, beep - i) / (rate * 0.005)); // no clicks
        final v = sin(2 * pi * 1000 * i / rate) * env * 0.9 * 32767;
        data.setInt16(44 + (b * (beep + gap) + i) * 2, v.round(), Endian.little);
      }
    }
    await f.writeAsBytes(data.buffer.asUint8List(), flush: true);
    return f.path;
  }
}
