import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

final FlutterLocalNotificationsPlugin notifications =
    FlutterLocalNotificationsPlugin();

const kServiceChannelId = 'price_monitor';
// v2: sound is now played by the service (Ringer) so it can loop until
// stopped; this channel only shows the heads-up / lock-screen notification.
const kAlertChannelId = 'price_alarm_v2';
const kStopAction = 'stop_alarm';

@pragma('vm:entry-point')
void _onNotificationResponse(NotificationResponse r) {
  if (r.actionId == kStopAction) {
    FlutterBackgroundService().invoke('stopAlarm');
  }
}

/// Safe to call from both the UI isolate and the background isolate.
Future<void> initNotifications() async {
  await notifications.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(),
    ),
    onDidReceiveNotificationResponse: _onNotificationResponse,
  );
  final android = notifications.resolvePlatformSpecificImplementation<
      AndroidFlutterLocalNotificationsPlugin>();

  // Quiet channel for the always-on "monitoring" notification.
  await android?.createNotificationChannel(const AndroidNotificationChannel(
    kServiceChannelId,
    'Price monitor',
    description: 'Keeps the live Binance price connection running',
    importance: Importance.low,
  ));

  await android?.deleteNotificationChannel('price_alarm_v1');

  // Max-importance channel for the alarm notification (shows on lock screen).
  // Silent: the looping sound comes from Ringer, not from the channel.
  await android?.createNotificationChannel(const AndroidNotificationChannel(
    kAlertChannelId,
    'Price alarms',
    description: 'Shown while a price alarm is ringing',
    importance: Importance.max,
    playSound: false,
    enableVibration: true,
  ));
}

Future<void> showAlarmNotification({
  required int id,
  required String title,
  required String body,
}) async {
  final android = AndroidNotificationDetails(
    kAlertChannelId,
    'Price alarms',
    channelDescription: 'Rings when a price target is hit',
    importance: Importance.max,
    priority: Priority.max,
    category: AndroidNotificationCategory.alarm,
    fullScreenIntent: true,
    visibility: NotificationVisibility.public,
    // Stays until the user stops the alarm (Stop button or in the app).
    ongoing: true,
    autoCancel: false,
    actions: const [
      AndroidNotificationAction(kStopAction, 'Stop alarm',
          showsUserInterface: true, cancelNotification: false),
    ],
    styleInformation: BigTextStyleInformation(body),
    ticker: title,
  );
  await notifications.show(
    id,
    title,
    body,
    NotificationDetails(
      android: android,
      iOS: const DarwinNotificationDetails(
        presentSound: true,
        presentAlert: true,
        interruptionLevel: InterruptionLevel.timeSensitive,
      ),
    ),
  );
}
