import 'dart:typed_data';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

final FlutterLocalNotificationsPlugin notifications =
    FlutterLocalNotificationsPlugin();

const kServiceChannelId = 'price_monitor';
const kAlertChannelId = 'price_alarm_v1';

/// Safe to call from both the UI isolate and the background isolate.
Future<void> initNotifications() async {
  await notifications.initialize(const InitializationSettings(
    android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    iOS: DarwinInitializationSettings(),
  ));
  final android = notifications.resolvePlatformSpecificImplementation<
      AndroidFlutterLocalNotificationsPlugin>();

  // Quiet channel for the always-on "monitoring" notification.
  await android?.createNotificationChannel(const AndroidNotificationChannel(
    kServiceChannelId,
    'Price monitor',
    description: 'Keeps the live Binance price connection running',
    importance: Importance.low,
  ));

  // Loud channel: uses the ALARM audio stream + the phone's alarm ringtone,
  // so it sounds even when the phone is locked.
  await android?.createNotificationChannel(const AndroidNotificationChannel(
    kAlertChannelId,
    'Price alarms',
    description: 'Rings when a price target is hit',
    importance: Importance.max,
    playSound: true,
    enableVibration: true,
    audioAttributesUsage: AudioAttributesUsage.alarm,
    sound: UriAndroidNotificationSound('content://settings/system/alarm_alert'),
  ));
}

Future<void> showAlarmNotification({
  required int id,
  required String title,
  required String body,
}) async {
  final android = AndroidNotificationDetails(
    kAlertChannelId,
    'Price alarms',
    channelDescription: 'Rings when a price target is hit',
    importance: Importance.max,
    priority: Priority.max,
    category: AndroidNotificationCategory.alarm,
    fullScreenIntent: true,
    visibility: NotificationVisibility.public,
    audioAttributesUsage: AudioAttributesUsage.alarm,
    // 4 = FLAG_INSISTENT: keep repeating the sound until the user dismisses it.
    additionalFlags: Int32List.fromList(<int>[4]),
    styleInformation: BigTextStyleInformation(body),
    ticker: title,
  );
  await notifications.show(
    id,
    title,
    body,
    NotificationDetails(
      android: android,
      iOS: const DarwinNotificationDetails(
        presentSound: true,
        presentAlert: true,
        interruptionLevel: InterruptionLevel.timeSensitive,
      ),
    ),
  );
}
