import 'dart:ui';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'monitor.dart';
import 'notifier.dart';

Future<void> configureService() async {
  await FlutterBackgroundService().configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onStart,
      autoStart: false, // started from the UI after permissions are granted
      autoStartOnBoot: true,
      isForegroundMode: true,
      notificationChannelId: kServiceChannelId,
      initialNotificationTitle: 'Price Alerts',
      initialNotificationContent: 'Connecting to Binance…',
      foregroundServiceNotificationId: 888,
      foregroundServiceTypes: [AndroidForegroundType.specialUse],
    ),
    iosConfiguration: IosConfiguration(
      autoStart: false,
      onForeground: onStart,
      onBackground: onIosBackground,
    ),
  );
}

@pragma('vm:entry-point')
Future<bool> onIosBackground(ServiceInstance service) async => true;

@pragma('vm:entry-point')
Future<void> onStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();
  await initNotifications();

  final monitor = Monitor(service);
  service.on('sync').listen((_) => monitor.sync());
  service.on('alerts').listen((_) => monitor.reloadAlerts());
  service.on('reload').listen((_) => monitor.reload());
  service.on('stop').listen((_) async {
    await monitor.dispose();
    service.stopSelf();
  });

  await monitor.start();
}
