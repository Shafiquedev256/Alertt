import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'models.dart';

/// Returns {symbol: lastPrice} for every symbol on the market, or null if the
/// request failed (offline, geo-blocked, etc.).
Future<Map<String, double>?> fetchSnapshot(Market m) async {
  final url = m == Market.spot
      ? '$kSpotRest/api/v3/ticker/price'
      : '$kFuturesRest/fapi/v1/ticker/price';
  try {
    final r =
        await http.get(Uri.parse(url)).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) return null;
    final list = jsonDecode(r.body) as List;
    return {
      for (final e in list)
        (e as Map)['symbol'] as String: double.parse(e['price'] as String)
    };
  } catch (_) {
    return null;
  }
}
