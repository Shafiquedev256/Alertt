import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'binance_api.dart';
import 'config.dart';
import 'models.dart';
import 'notifier.dart';
import 'storage.dart';

/// One WebSocket per market (spot / futures), auto-reconnecting.
class _Feed {
  _Feed(this.market, this.onTick, this.onChange);

  final Market market;
  final void Function(String key, double price) onTick;
  final void Function() onChange;

  List<String> _symbols = [];
  WebSocketChannel? _ch;
  StreamSubscription? _sub;
  Timer? _retry;
  int _attempt = 0;
  DateTime _last = DateTime.now();
  bool connected = false;

  bool get wanted => _symbols.isNotEmpty;

  void setSymbols(List<String> s) {
    final sorted = [...s]..sort();
    if (sorted.join(',') == _symbols.join(',') &&
        (_ch != null || _retry != null)) {
      return;
    }
    _symbols = sorted;
    _teardown();
    if (_symbols.isNotEmpty) _connect();
  }

  void _connect() {
    final base = market == Market.spot ? kSpotWs : kFuturesWs;
    final streams =
        _symbols.map((s) => '${s.toLowerCase()}@miniTicker').join('/');
    final ch =
        WebSocketChannel.connect(Uri.parse('$base/stream?streams=$streams'));
    _ch = ch;
    _last = DateTime.now();
    ch.ready.then((_) {
      if (_ch == ch) {
        connected = true;
        _attempt = 0;
        onChange();
      }
    }).catchError((_) {});
    _sub = ch.stream.listen(
      (data) {
        _last = DateTime.now();
        _parse(data);
      },
      onError: (_) => _fail(ch),
      onDone: () => _fail(ch),
      cancelOnError: true,
    );
  }

  void _parse(dynamic raw) {
    try {
      final m = jsonDecode(raw as String) as Map<String, dynamic>;
      final d = m['data'] as Map<String, dynamic>?;
      if (d == null) return;
      final price = double.tryParse('${d['c']}');
      final sym = d['s'] as String?;
      if (price != null && sym != null) onTick('${market.name}:$sym', price);
    } catch (_) {}
  }

  void _fail(WebSocketChannel ch) {
    if (_ch != ch) return;
    _teardown();
    final secs = min(30, 1 << min(_attempt, 5));
    _attempt++;
    _retry = Timer(Duration(seconds: secs), () {
      _retry = null;
      if (_symbols.isNotEmpty) _connect();
    });
  }

  /// Called every few seconds: reconnect if the socket went silently dead
  /// (common after the phone has been asleep).
  void watchdog() {
    final ch = _ch;
    if (ch != null) {
      if (DateTime.now().difference(_last).inSeconds > 45) _fail(ch);
    } else if (_symbols.isNotEmpty && _retry == null) {
      _connect();
    }
  }

  void _teardown() {
    _retry?.cancel();
    _retry = null;
    _sub?.cancel();
    _sub = null;
    try {
      _ch?.sink.close();
    } catch (_) {}
    _ch = null;
    connected = false;
    onChange();
  }

  void dispose() {
    _symbols = [];
    _teardown();
  }
}

/// Lives inside the background-service isolate. Owns the sockets, checks
/// alerts on every tick, and rings the alarm. Works with the screen off.
class Monitor {
  Monitor(this.service);

  final ServiceInstance service;
  late final _Feed _spot = _Feed(Market.spot, _onTick, _onFeedChange);
  late final _Feed _fut = _Feed(Market.futures, _onTick, _onFeedChange);

  final Map<String, double> _prices = {};
  List<Instrument> _instruments = [];
  List<AlertRule> _alerts = [];
  Timer? _timer;
  Timer? _rediscover;
  bool _dirty = false;
  int _ticks = 0;
  String _status = 'Connecting…';

  Future<void> start() async {
    await reload();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      _ticks++;
      if (_dirty) {
        _dirty = false;
        service.invoke('prices', {'p': Map<String, double>.of(_prices)});
      }
      if (_ticks % 10 == 0) {
        _spot.watchdog();
        _fut.watchdog();
      }
    });
  }

  Future<void> reloadAlerts() async {
    _alerts = await Store.loadAlerts();
    _refreshNotification();
  }

  /// Full reload: alerts + which symbols actually exist on Binance + sockets.
  Future<void> reload() async {
    _alerts = await Store.loadAlerts();
    final custom = await Store.loadCustom();
    final all = <Instrument>[
      ...kCatalog,
      ...custom.where((c) => !kCatalog.any((k) => k.key == c.key)),
    ];

    final snaps = <Market, Map<String, double>?>{
      Market.spot: await fetchSnapshot(Market.spot),
      Market.futures: await fetchSnapshot(Market.futures),
    };
    final cached = await Store.loadInstruments();

    var failed = false;
    final list = <Instrument>[];
    for (final m in Market.values) {
      final snap = snaps[m];
      if (snap == null) {
        failed = true; // offline / blocked: fall back to last known list
        list.addAll(cached.where((i) => i.market == m));
      } else {
        for (final i in all.where((i) => i.market == m)) {
          final p = snap[i.symbol];
          if (p != null) {
            list.add(i);
            _prices[i.key] = p;
          }
        }
      }
    }

    _instruments = list;
    _dirty = true;
    if (!failed) await Store.saveInstruments(list);

    _spot.setSymbols(
        list.where((i) => i.market == Market.spot).map((i) => i.symbol).toList());
    _fut.setSymbols(list
        .where((i) => i.market == Market.futures)
        .map((i) => i.symbol)
        .toList());

    sync();
    _refreshNotification();

    _rediscover?.cancel();
    if (failed) _rediscover = Timer(const Duration(seconds: 20), reload);
  }

  void sync() {
    service.invoke('instruments',
        {'list': _instruments.map((i) => i.toJson()).toList()});
    service.invoke('prices', {'p': Map<String, double>.of(_prices)});
    service.invoke('status', {'s': _status});
  }

  void _onFeedChange() {
    final wanted = [_spot, _fut].where((f) => f.wanted).toList();
    final up = wanted.where((f) => f.connected).length;
    _status = wanted.isEmpty
        ? 'No markets'
        : up == wanted.length
            ? 'Live'
            : up == 0
                ? 'Reconnecting…'
                : 'Partially connected';
    service.invoke('status', {'s': _status});
    _refreshNotification();
  }

  void _onTick(String key, double price) {
    _prices[key] = price;
    _dirty = true;
    for (final a in _alerts) {
      if (!a.active || a.key != key) continue;
      final hit = a.above ? price >= a.target : price <= a.target;
      if (hit) _fire(a, price);
    }
  }

  Future<void> _fire(AlertRule a, double price) async {
    a.active = false; // set synchronously so later ticks can't re-fire it
    a.firedAt = DateTime.now().millisecondsSinceEpoch;
    a.firedPrice = price;
    await Store.updateAlert(a);
    await showAlarmNotification(
      id: a.id.hashCode & 0x7fffffff,
      title: '🔔 ${a.label}',
      body: '${a.label} hit ${fmtPrice(price)} '
          '(target ${a.above ? '≥' : '≤'} ${fmtPrice(a.target)})',
    );
    service.invoke('fired', {'id': a.id});
    _refreshNotification();
  }

  void _refreshNotification() {
    final s = service;
    if (s is AndroidServiceInstance) {
      final n = _alerts.where((a) => a.active).length;
      s.setForegroundNotificationInfo(
        title: 'Price Alerts · $_status',
        content: '$n active alert${n == 1 ? '' : 's'} · '
            '${_instruments.length} markets',
      );
    }
  }

  Future<void> dispose() async {
    _timer?.cancel();
    _rediscover?.cancel();
    _spot.dispose();
    _fut.dispose();
  }
}
