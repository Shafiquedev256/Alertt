import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

/// Shared by the UI isolate and the background-service isolate.
/// Every read calls reload() so each isolate sees the other's writes.
class Store {
  static const _alerts = 'alerts_v1';
  static const _custom = 'custom_v1';
  static const _instr = 'instruments_v1';

  static Future<SharedPreferences> _fresh() async {
    final p = await SharedPreferences.getInstance();
    await p.reload();
    return p;
  }

  static Future<List<AlertRule>> loadAlerts() async {
    final raw = (await _fresh()).getString(_alerts);
    if (raw == null) return [];
    return (jsonDecode(raw) as List)
        .map((e) => AlertRule.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  static Future<void> saveAlerts(List<AlertRule> rules) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_alerts, jsonEncode(rules.map((e) => e.toJson()).toList()));
  }

  /// Replace one rule by id (used by the service when an alert fires).
  static Future<void> updateAlert(AlertRule a) async {
    final rules = await loadAlerts();
    final i = rules.indexWhere((r) => r.id == a.id);
    if (i >= 0) {
      rules[i] = a;
      await saveAlerts(rules);
    }
  }

  static Future<List<Instrument>> _loadInstr(String key) async {
    final raw = (await _fresh()).getString(key);
    if (raw == null) return [];
    return (jsonDecode(raw) as List)
        .map((e) => Instrument.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  static Future<void> _saveInstr(String key, List<Instrument> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(key, jsonEncode(l.map((e) => e.toJson()).toList()));
  }

  static Future<List<Instrument>> loadCustom() => _loadInstr(_custom);

  static Future<void> addCustom(Instrument i) async {
    final l = await loadCustom();
    if (l.any((x) => x.key == i.key)) return;
    l.add(i);
    await _saveInstr(_custom, l);
  }

  static Future<List<Instrument>> loadInstruments() => _loadInstr(_instr);
  static Future<void> saveInstruments(List<Instrument> l) =>
      _saveInstr(_instr, l);
}
