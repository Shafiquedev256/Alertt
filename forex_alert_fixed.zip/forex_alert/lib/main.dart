import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'background.dart';
import 'binance_api.dart';
import 'models.dart';
import 'notifier.dart';
import 'storage.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initNotifications();
  await configureService();
  runApp(const ForexAlertApp());
}

class ForexAlertApp extends StatelessWidget {
  const ForexAlertApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Forex Alerts',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorSchemeSeed: Colors.amber,
        ),
        home: const HomeScreen(),
      );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _service = FlutterBackgroundService();
  final List<StreamSubscription> _subs = [];

  int _tab = 0;
  List<Instrument> _instruments = [];
  final Map<String, double> _prices = {};
  final Map<String, int> _dir = {};
  List<AlertRule> _alerts = [];
  String _status = 'Starting…';
  bool _running = false;

  @override
  void initState() {
    super.initState();
    _subs.add(_service.on('prices').listen((e) {
      final p = (e?['p'] as Map?)
          ?.map((k, v) => MapEntry(k as String, (v as num).toDouble()));
      if (p == null || !mounted) return;
      setState(() {
        p.forEach((k, v) {
          final old = _prices[k];
          if (old != null && v != old) _dir[k] = v > old ? 1 : -1;
          _prices[k] = v;
        });
      });
    }));
    _subs.add(_service.on('instruments').listen((e) {
      final l = (e?['list'] as List?)
          ?.map((x) => Instrument.fromJson(Map<String, dynamic>.from(x as Map)))
          .toList();
      if (l != null && mounted) setState(() => _instruments = l);
    }));
    _subs.add(_service.on('status').listen((e) {
      if (mounted) setState(() => _status = (e?['s'] as String?) ?? _status);
    }));
    _subs.add(_service.on('fired').listen((_) async {
      final a = await Store.loadAlerts();
      if (!mounted) return;
      setState(() => _alerts = a);
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('🔔 An alert fired')));
    }));
    _boot();
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }

  Future<void> _boot() async {
    final cached = await Store.loadInstruments();
    final alerts = await Store.loadAlerts();
    if (mounted) {
      setState(() {
        _instruments = cached;
        _alerts = alerts;
      });
    }
    await _askNotificationPermission();
    if (!await _service.isRunning()) await _service.startService();
    await Future.delayed(const Duration(seconds: 1));
    _service.invoke('sync');
    _refreshRunning();
  }

  Future<void> _askNotificationPermission() async {
    final android = notifications.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await android?.requestNotificationsPermission();
  }

  Future<void> _refreshRunning() async {
    final r = await _service.isRunning();
    if (mounted) setState(() => _running = r);
  }

  // ---------- actions ----------

  Future<void> _addAlert(Instrument i) async {
    final cur = _prices[i.key];
    final ctrl = TextEditingController(text: cur == null ? '' : fmtPrice(cur));
    final target = await showDialog<double>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Alert: ${i.label}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Current price: ${cur == null ? '—' : fmtPrice(cur)}'),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              autofocus: true,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration:
                  const InputDecoration(labelText: 'Alert when price reaches'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
          FilledButton(
            onPressed: () =>
                Navigator.pop(c, double.tryParse(ctrl.text.replaceAll(',', '.'))),
            child: const Text('Set alert'),
          ),
        ],
      ),
    );
    if (target == null || target <= 0) return;
    final rules = await Store.loadAlerts();
    rules.add(AlertRule(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      key: i.key,
      label: i.label,
      above: cur == null ? true : target > cur,
      target: target,
    ));
    await Store.saveAlerts(rules);
    _service.invoke('alerts');
    if (mounted) setState(() => _alerts = rules);
  }

  Future<void> _addSymbol() async {
    final ctrl = TextEditingController();
    var market = Market.futures;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: const Text('Add Binance symbol'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: ctrl,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(labelText: 'e.g. XAGUSDT'),
            ),
            const SizedBox(height: 12),
            SegmentedButton<Market>(
              segments: const [
                ButtonSegment(value: Market.spot, label: Text('Spot')),
                ButtonSegment(value: Market.futures, label: Text('Futures')),
              ],
              selected: {market},
              onSelectionChanged: (s) => setD(() => market = s.first),
            ),
          ]),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(c, false),
                child: const Text('Cancel')),
            FilledButton(
                onPressed: () => Navigator.pop(c, true),
                child: const Text('Add')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final sym = ctrl.text.trim().toUpperCase();
    final snap = await fetchSnapshot(market);
    if (!mounted) return;
    if (snap == null || !snap.containsKey(sym)) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('$sym not found on Binance ${market.name}')));
      return;
    }
    await Store.addCustom(Instrument(sym, sym, 'Custom', market));
    _service.invoke('reload');
  }

  Future<void> _toggle(AlertRule a, bool on) async {
    final rules = await Store.loadAlerts();
    final i = rules.indexWhere((r) => r.id == a.id);
    if (i < 0) return;
    rules[i].active = on;
    if (on) {
      rules[i].firedAt = null;
      rules[i].firedPrice = null;
    }
    await Store.saveAlerts(rules);
    _service.invoke('alerts');
    if (mounted) setState(() => _alerts = rules);
  }

  Future<void> _delete(AlertRule a) async {
    final rules = await Store.loadAlerts();
    rules.removeWhere((r) => r.id == a.id);
    await Store.saveAlerts(rules);
    _service.invoke('alerts');
    if (mounted) setState(() => _alerts = rules);
  }

  // ---------- UI ----------

  Color? _dirColor(String key) => _dir[key] == 1
      ? Colors.greenAccent
      : _dir[key] == -1
          ? Colors.redAccent
          : null;

  Widget _markets() {
    if (_instruments.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    final groups = <String, List<Instrument>>{};
    for (final i in _instruments) {
      groups.putIfAbsent(i.group, () => []).add(i);
    }
    return ListView(children: [
      for (final e in groups.entries) ...[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
          child: Text(e.key.toUpperCase(),
              style: Theme.of(context).textTheme.labelMedium),
        ),
        for (final i in e.value)
          ListTile(
            title: Text(i.label),
            subtitle: Text(
                '${i.symbol} · ${i.market == Market.spot ? 'spot' : 'futures'}'),
            trailing: Text(
              _prices[i.key] == null ? '—' : fmtPrice(_prices[i.key]!),
              style: TextStyle(fontSize: 18, color: _dirColor(i.key)),
            ),
            onTap: () => _addAlert(i),
          ),
      ],
      const SizedBox(height: 24),
    ]);
  }

  Widget _alertsTab() {
    if (_alerts.isEmpty) {
      return const Center(
          child: Padding(
        padding: EdgeInsets.all(32),
        child: Text('No alerts yet.\nTap any market to create one.',
            textAlign: TextAlign.center),
      ));
    }
    return ListView(children: [
      for (final a in _alerts)
        Dismissible(
          key: ValueKey(a.id),
          background: Container(color: Colors.red),
          onDismissed: (_) => _delete(a),
          child: ListTile(
            title: Text(a.label),
            subtitle: Text(
              '${a.above ? '≥' : '≤'} ${fmtPrice(a.target)}'
              '${a.firedPrice != null ? '  ·  fired at ${fmtPrice(a.firedPrice!)}' : ''}',
            ),
            trailing: Switch(value: a.active, onChanged: (v) => _toggle(a, v)),
          ),
        ),
    ]);
  }

  Widget _setup() => ListView(padding: const EdgeInsets.all(16), children: [
        Card(
          child: ListTile(
            leading: Icon(_status == 'Live' ? Icons.bolt : Icons.sync_problem),
            title: Text('Feed: $_status'),
            subtitle: Text(
                'Background monitor: ${_running ? 'running' : 'stopped'}'),
            trailing: Switch(
              value: _running,
              onChanged: (v) async {
                if (v) {
                  await _service.startService();
                  await Future.delayed(const Duration(seconds: 1));
                  _service.invoke('sync');
                } else {
                  _service.invoke('stop');
                }
                await Future.delayed(const Duration(milliseconds: 600));
                _refreshRunning();
              },
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'For alarms to ring with the screen off, do all of these once:',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 8),
        FilledButton.tonalIcon(
          icon: const Icon(Icons.notifications_active),
          label: const Text('1. Allow notifications'),
          onPressed: _askNotificationPermission,
        ),
        const SizedBox(height: 8),
        FilledButton.tonalIcon(
          icon: const Icon(Icons.battery_saver),
          label: const Text('2. Disable battery optimisation'),
          onPressed: () => Permission.ignoreBatteryOptimizations.request(),
        ),
        const SizedBox(height: 8),
        FilledButton.tonalIcon(
          icon: const Icon(Icons.settings),
          label: const Text('3. Open app settings (allow autostart / lock-screen)'),
          onPressed: openAppSettings,
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          icon: const Icon(Icons.alarm),
          label: const Text('Test alarm now'),
          onPressed: () => showAlarmNotification(
            id: 1,
            title: '🔔 Test alarm',
            body: 'If you hear this with the phone locked, alarms work.',
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'Tip: lock your screen, then tap “Test alarm” and wait ~1s. '
          'On Xiaomi / Oppo / Vivo / Samsung also lock the app in recents and '
          'enable Autostart (see dontkillmyapp.com).',
        ),
      ]);

  @override
  Widget build(BuildContext context) {
    final pages = [_markets(), _alertsTab(), _setup()];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Forex Alerts'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Center(
              child: Text(_status,
                  style: TextStyle(
                      color: _status == 'Live' ? Colors.greenAccent : null)),
            ),
          ),
          if (_tab == 0)
            IconButton(
                icon: const Icon(Icons.add), onPressed: _addSymbol,
                tooltip: 'Add symbol'),
        ],
      ),
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.show_chart), label: 'Markets'),
          NavigationDestination(
              icon: Icon(Icons.notifications), label: 'Alerts'),
          NavigationDestination(icon: Icon(Icons.tune), label: 'Setup'),
        ],
      ),
    );
  }
}
