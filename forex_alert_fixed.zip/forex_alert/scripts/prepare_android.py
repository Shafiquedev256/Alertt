from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
app_gradle_kts = root / 'android' / 'app' / 'build.gradle.kts'
app_gradle = root / 'android' / 'app' / 'build.gradle'
overlay = root / 'android_overlay' / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
manifest = root / 'android' / 'app' / 'src' / 'main' / 'AndroidManifest.xml'

if not (app_gradle_kts.exists() or app_gradle.exists()):
    raise SystemExit('Android app Gradle file was not generated.')

# Use the project's Android manifest, which declares the foreground service,
# notification and lock-screen permissions needed by this app.
if overlay.exists():
    manifest.parent.mkdir(parents=True, exist_ok=True)
    manifest.write_text(overlay.read_text(), encoding='utf-8')

if app_gradle_kts.exists():
    p = app_gradle_kts
    s = p.read_text(encoding='utf-8')
    if 'isCoreLibraryDesugaringEnabled = true' not in s:
        s = s.replace('android {', 'android {\n    compileOptions {\n        isCoreLibraryDesugaringEnabled = true\n    }', 1)
    if 'coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:' not in s:
        dep = '    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n'
        if re.search(r'\ndependencies\s*\{', s):
            s = re.sub(r'(\ndependencies\s*\{\n)', r'\1' + dep, s, count=1)
        else:
            s += '\n\ndependencies {\n' + dep + '}\n'
    p.write_text(s, encoding='utf-8')
else:
    p = app_gradle
    s = p.read_text(encoding='utf-8')
    if 'coreLibraryDesugaringEnabled true' not in s:
        s = s.replace('android {', 'android {\n    compileOptions {\n        coreLibraryDesugaringEnabled true\n    }', 1)
    if "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:" not in s:
        dep = "    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n"
        if re.search(r'\ndependencies\s*\{', s):
            s = re.sub(r'(\ndependencies\s*\{\n)', r'\1' + dep, s, count=1)
        else:
            s += "\n\ndependencies {\n" + dep + '}\n'
    p.write_text(s, encoding='utf-8')
