# Build the Forex Alerts APK with GitHub Actions

This repository contains the Flutter/Dart source and Android manifest overlay. The standard
Flutter `android/` wrapper is generated automatically on the GitHub Actions runner, so you do
not need Android Studio just to build the APK.

## Build

1. Push the project to GitHub, including `.github/workflows/build-apk.yml` and `scripts/prepare_android.py`.
2. Open the repository on GitHub and select **Actions**.
3. Select **Build Flutter APK**.
4. Click **Run workflow** and choose the `main` branch.
5. Wait for the green **Success** result.
6. Open the successful run and scroll to **Artifacts**.
7. Download **forex-alert-release-apk**. It is a ZIP containing `app-release.apk`.

A push to `main` also starts a build automatically.
